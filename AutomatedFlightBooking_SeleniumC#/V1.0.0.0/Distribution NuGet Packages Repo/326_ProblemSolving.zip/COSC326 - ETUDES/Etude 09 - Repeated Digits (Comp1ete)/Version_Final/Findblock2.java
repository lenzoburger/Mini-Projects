// Etude 9 Lennox Huang 1663448
import java.util.Stack;

public class Findblock2 {
  static int baseNums;
  static int integerNums;
  static int countRepeat;
  static int start = 0;
  
  public static void main(String[] args) {
    baseNums = Integer.parseInt(args[0]);
    integerNums = Integer.parseInt(args[1]);  
    int count = 0;
    int fin = 0;
    //calResult(baseNums, integerNums - 1, 0);
    
        
    int j = 1;
    while (true) {
      if (calResult(baseNums, j) && calResult(integerNums ,j)) {
        System.out.println(j);
        return;
      }
     // System.out.println("\n");
      j++;
    }
    
  }
  
  public static boolean calResult(int b, int n) {
    Stack<Integer> stack = new Stack<Integer>();
    String numbers = "";
    int check = n;
    boolean[] counter = new boolean[b];
    boolean repeated = false;
    int c;
    
    if(b == 0){
      System.out.println("0");
    }
    
    while (n > 0) {
      stack.add(n % b);
      n = n / b;
    }
    /*
    if (n == 0) {
      check--;
    }
    */
    while(!stack.isEmpty()){
      
      c = stack.pop();
      if(counter[c]){
        repeated = true;
      }else{
        counter[c] = true;
      }
      numbers += c; // reverse the number
    }
    
    /*    
     if (!repeated) {
     if (count > countRepeat) {
     countRepeat = count;
     System.out.println(check + " < " + start + "?");
     if (check < start)start = check + 2;
     }
     count = 0;
     } else {
     count++;
     }
     */
    
   //System.out.print("base: " + b + " " + numbers + " " + repeated + " || ");
    //System.out.printf("The Numbers is %-5s, when n is %-2s %s", 
     //                 numbers, (check + 1) ,repeated? "REPEATED\n":"\n");
    return repeated;
    /**
     if (check > 0) {
     calResult(baseNums, check, count);
     }
     **/
  }
  
}