import java.math.*;
import java.util.*;

public class StdDev{
    public static void main(String args[]) {
        ArrayList<Integer> intList= new ArrayList<Integer>();
        Scanner scan = new Scanner(System.in);
        /*while (scan.hasNextInt()) {
            intList.add(scan.nextInt());
            }*/
        // Integer[] a = intList.toArray(new Integer[intList.size()]);
        Random random = new Random(1); 
        Double[] a = new Double[100];
        for (int i = 0; i < a.length; i++) {
            a[i] = random.nextDouble() * 100;
        }
               
        System.out.println("std dev 1: " + calcStdDev1(a));
        System.out.println("std dev 2: " + calcStdDev2(a));
    }

    public static double getMean(Double[] a) {
        double sum = 0;
        for (int i = 0; i < a.length; i++) {
            sum += a[i];
        }
        return sum / a.length;
    }
            
    public static double calcStdDev1(Double[] a) {
        double mean = getMean(a);
        double sum = 0;
        for (int i = 0; i < a.length; i++) {
            sum += Math.pow((a[i] - mean), 2);
        }
        return (double)Math.sqrt(sum / a.length);
    }

    public static double calcStdDev2(Double[] a) {
        double sumSquared = 0;
        double sumOfSquares = 0;
        for (int i = 0; i < a.length; i++) {
            sumOfSquares += Math.pow(a[i], 2);
            sumSquared += a[i];
        }
        sumSquared = (double)(Math.pow(sumSquared, 2))  / a.length;
        
        return (double)Math.sqrt((sumOfSquares - (sumSquared)) / a.length);
    }

}
