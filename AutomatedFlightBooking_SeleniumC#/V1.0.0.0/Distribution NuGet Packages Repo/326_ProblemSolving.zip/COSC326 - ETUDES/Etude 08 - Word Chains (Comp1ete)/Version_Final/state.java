package Version_2; 
public enum state{
    UNVISITED, VISITED_SELF,VISITED_DESCENDANTS;    
}