// demonstrates depth-first search
package Etude8;
import java.util.*;

public class DFSApp {       
    
    public static void main(String[] args) {
        Graph g= new Graph();       
        ArrayList pieces = new ArrayList<>();
        boolean added= false;
        String start = args[0];
        String end = args[1];
        String chain;
        int length;
        
        Scanner in = new Scanner(System.in);
        g.addVertex(start);          
        while (in.hasNextLine()){
            String word = in.nextLine();
            pieces.add(word);
            
            if(word.equals(start) && !added){
                added = true;
            }else{
                g.addVertex(word);
            }                    
        }        
        switch (args[1]) {
        default:
            length=0;
        }
        
        //System.out.println(g.nVerts);
        relationShips(g); //determine relatioships      
        g.displayVertex(0); // depth-first search        
     
    }  // end main()
    
    
    public static void relationShips (Graph g){
        //System.out.println(g.nVerts);
        for(int i=0;i<g.nVerts;i++){
            ///System.out.println("am here");
            for(int j=0; j<g.nVerts; j++){
                if(matching(g.vertexList[j].label,g.vertexList[i].label)){
                    //System.out.println(g.vertexList[i].label + " " + g.vertexList[j].label);
                    g.addEdge(i,j);
                }
            }
        }
                 
    }

    public static boolean matching (String s1, String s2){
        int l= s1.length();
        int matches=0;
        for(int i=0;i<l;i++){
            if(s1.charAt(i)==s2.charAt(i)){
                matches++;
            }
        }

        if(matches==l-1){
            return true;
        }
        return false;
    }
                
                
  
}  // end class DFSApp




