package Etude8;
public class Vertex {
    public String label;        // label (e.g. 'A')
    public boolean wasVisited;
   
    public Vertex(String lab)   // constructor
    {
        label = lab;
        wasVisited = false;
    }
  
}  // end class Vertex
