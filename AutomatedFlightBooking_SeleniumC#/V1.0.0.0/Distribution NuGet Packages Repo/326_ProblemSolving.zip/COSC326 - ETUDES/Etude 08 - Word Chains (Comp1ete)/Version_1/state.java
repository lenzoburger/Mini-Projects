package word2Chainz; 
public enum state{
    UNVISITED, VISITED_SELF,VISITED_DESCENDANTS;    
}