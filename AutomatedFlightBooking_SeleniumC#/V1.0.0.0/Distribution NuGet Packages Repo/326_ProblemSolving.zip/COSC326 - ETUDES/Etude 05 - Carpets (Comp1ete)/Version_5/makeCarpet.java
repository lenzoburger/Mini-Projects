//File: makeCarpet.java - March 2015
package Etude5;

/**
 * An application class  which is to manipulate a list of capet strips and number of stock according
 * to a set of instructions from stdin.
 *
 * @author(s)  Daisy, Lencho, Lennox, Nikhil.
 */

import java.util.Scanner;

public class makeCarpet {
    public static int index=0;
    public static int size;
   
    /**
     *  A main method which read input from stdin one line at a time, and 
     *  call the method handleLine().
     */
    public static void main(String[] args) {        
        String line;
        Scanner input = new Scanner(System.in);
        Scanner cSize = new Scanner(args[0]);
        carpet stock = new carpet();
        while (input.hasNextLine()) {
            line=input.nextLine();
            line=line.toLowerCase();
            if(cSize.hasNextInt()){                
                if (args.length == 1){                
                    size=Integer.parseInt(args[0]);
                    handleLine(line,stock);
                }else{
                    System.out.println("Error: improper carpet size specified");
                    break;
                }
            }else{
                System.out.println("Error: please  enter a numerical carpet size");
                break;
            }
        }
        System.out.println(stock.toString());
    }
    
   
    /** A method that handles the instance of carpet according to
     *  different instructions of each line.
     *  @param line: one line of string from stdin
     *  @param stock: an instance of carpet to be handled
     */
    public static void handleLine(String line, carpet stock) {
        Scanner tokens = new Scanner(line);
        if (tokens.hasNext("-[nmbp]")) {
            char command = tokens.next().charAt(1);
            switch (command) {
                /**produce a carpet with no matches */
            case 'n':    
                if (!(tokens.hasNext())) {
                    stock.noMatches();
                }else{
                    System.out.println(line + "invalid input");
                }                 
                break;
                /** produce a carpet with maximum matches */
            case 'm':         
                if (!(tokens.hasNext())) {
                    stock.maxMatches();
                }else{
                    System.out.println(line + "invalid input");
                }                 
                break;
                /** produce a carpet with balanced matches */
            case 'b':
                if (!(tokens.hasNext())) {
                    stock.balMatches();
                }else{
                    System.out.println(line + "invalid input");
                }                 
                break;
                /** print out the stock using its toString() method */
            case 'p':
                System.out.println(stock.toString());
                break;
            }                          
        }else if(tokens.hasNext()){
            String k= tokens.next();
            String reverse= new StringBuilder(k).reverse().toString();
            if( k.charAt(0)>='a'&&k.charAt(0)<='z'){                
                int num;
                if(index==0){
                    index=k.length();
                }

                if(k.length()==index&&index>0){
                    if(stock.contains(reverse)){          
                        num=stock.inStock(reverse);                        
                        stock.remove(reverse);
                        stock.addEntry(reverse,num+1);
                    }else if(stock.contains(k)){          
                        num=stock.inStock(k);                        
                        stock.remove(k);
                        stock.addEntry(k,num+1);
                    }else{
                        //System.out.println(reverse+ " <> "+k);
                        stock.addEntry(k,1);        
                    }
                }else{
                    System.out.println("All Carpet strips must be of same size ");

                }
            }else{
                System.out.println("Invalid entry: ");
            }
        }else{
            System.out.println("Invalid entry: ");
        }
    }
}
    
            
            
            

        


         
