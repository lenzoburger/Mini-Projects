package Version_7;
import java.util.*;

public class balMatchGraph{
  public String printErr="";
  private final int MAX_PIECES;
  public Piece pieceList[]; // list of vertices
  public int adjMat[][];      // adjacency matrix
  public int nPieces;          // current number of vertices
  public int words=0;
  private Queue<Integer> stackQ = new LinkedList<Integer>();
  
  public balMatchGraph(int size){               // constructor
    MAX_PIECES= size;
    pieceList = new Piece[MAX_PIECES];
    // adjacency matrix
    adjMat = new int[MAX_PIECES][MAX_PIECES];
    nPieces = 0;
    for(int y=0; y<MAX_PIECES; y++)      // set adjacency
      for(int x=0; x<MAX_PIECES; x++)   //    matrix to 0
      adjMat[x][y] = 0;        
  }  // end constructor
  
  
  public void addPiece(String lab, int p){
    pieceList[p] = new Piece(lab,p);
    pieceList[p].state= State.UNVISITED;  
    pieceList[p].dfs_distance=0;
    pieceList[p].bfs_distance=-1;
    pieceList[p].ending=0;
    pieceList[p].ancestor=-1;
    pieceList[p].count=0;
    nPieces++;
    //System.out.println(nPieces);
  }
  
  
  public void addEdge(int start, int end, int matches){
    adjMat[start][end] = matches;
    adjMat[end][start] = matches;
  } 
  
  public void relationShips (){
    //System.out.println(g.nPieces);
    for(int i=0;i<nPieces;i++){
      ///System.out.println("am here");
      for(int j=0; j<nPieces; j++){
        int matching=matches(pieceList[i].toString(), pieceList[j].toString());
        if(matching>0 && (adjMat[i][j])==0 && i!=j){          
          addEdge(i,j,matching);
          //System.out.println( (pieceList[i]) + " and  " + (pieceList[j]) + " have " + matching + " matches");
        }        
      }
    }
    
  }
  
  private int matches(String p1, String p2){
    int matching=0;
    int revMatch=0;
    String reverse= new StringBuilder(p2).reverse().toString();
    for(int i=0;i<p2.length();i++){
      if(p1.charAt(i)==p2.charAt(i)){
        matching++;
      }
      if(p1.charAt(i)==reverse.charAt(i)){
        revMatch++;
      }
    }
    if(revMatch>matching){
      //isReverse=true;
      return revMatch;
    }
    return matching;
  }
  
  /*public void displayRelationships() {
   for(int r=0;r<nPieces;r++){
   System.out.print(pieceList[r].label + ": ");
   for(int c=0;c<nPieces;c++){
   if(adjMat[r][c]==true){
   System.out.print(pieceList[c].label + ", ");
   }
   }
   System.out.println();
   }
   }*/
  
  public void displayPiece(int v) {
    System.out.println(pieceList[v]);
  }
  
  public void displayAdjMat() {
    for(int j=0;j<nPieces;j++){      
      System.out.print("    "+ pieceList[j].label);           
    }
    System.out.println();
    int i = 0;
    for(int[] row: adjMat){
      System.out.print(pieceList[i].label+ "  ");
      for(int col:row){
        System.out.print(col+"      ");         
      }
      System.out.println();
      System.out.println();
      if(i<nPieces-1){
        i++;
      }
    }  
  }
  
  public ArrayList<Integer> maxMatch(int size){
    int max=0;
    ArrayList<Integer> maxPiece= new ArrayList<Integer>();
    for(int i=0;i<pieceList.length;i++){
      ArrayList<Integer> matchTotalList= new ArrayList<Integer>();
      matchTotalList.add(i);
      matchTotalList= myMatchTotal(i, matchTotalList,size);
      int matchTotal= calculateListMatches(matchTotalList);
      if(matchTotal>max){
        max=matchTotal;
        maxPiece=(ArrayList<Integer>) matchTotalList.clone();
      }
    }
    return maxPiece;
  }
  
  public int calculateListMatches(ArrayList<Integer> list){
    int total=0;
    for(int i=0;i<list.size()-1;i++){
      int me= list.get(i);
      int you= list.get(i+1);
      total+=adjMat[me][you];
    }
    return total;
  }
  
  public ArrayList<Integer> myMatchTotal(int me,ArrayList<Integer>myList,int size){
    int bestMatch= findMyBest(myList,me);
    if(bestMatch>=0 && myList.size()<size){
      myList.add(bestMatch);
      myList=myMatchTotal(bestMatch,myList,size);
    }
    return myList;
  }
  
  public int findMyBest(ArrayList<Integer> myList, int me){
    int best=-1;
    int bestMatch=0;    
    for(int you=0;you<adjMat[me].length;you++){
      if(adjMat[me][you] > bestMatch && !(myList.contains(you))){
        best= you;
        bestMatch=adjMat[me][you];
      }      
    }
    return best;
  }
  
  public ArrayList<Integer> balancedMatches(int length, int size){   
     ArrayList<Integer> temp= new ArrayList<Integer>();
     ArrayList<Integer> list= new ArrayList<Integer>();
    for(int i=0;i<nPieces;i++){
      list.add(i);
    }
    
    for(int each: list){
      ArrayList<Integer> chain= new ArrayList<Integer> ();
       chain.add(each);
      temp= findEnd(each,chain,length, size);
      if(!(temp.isEmpty())){
        return temp;
      }
    }
    return temp;
  }
  
  public ArrayList<Integer> myChildren(int index,ArrayList<Integer> list){
    ArrayList<Integer> children= new ArrayList<Integer> ();
    //System.out.println("here " + index);
    for(int i=0;i<adjMat[index].length;i++){
      int each= adjMat[index][i];
      if(!(list.contains(i))){
        children.add(i);
        //System.out.println(vertexList[i] + " is a child of: " + vertexList[index]);
      }
    }
    return children;
  }
  
  public ArrayList<Integer> findEnd(int start, ArrayList<Integer> wordChain, int length, int size) {
    //System.out.println("here " + start);
    ArrayList<Integer> children= myChildren(start, wordChain);
    ArrayList<Integer> bogus= new ArrayList<Integer>();
    int total=calculateListMatches(wordChain);
    if(children.isEmpty()){
      if(total==length&&wordChain.size()==size){
        return wordChain;
      }else{
        return bogus;
      }
    }
    
    if(total==length){
      if(wordChain.size()==size){
        return wordChain;
      }else{
        return bogus;
      }
    }
    
    if(wordChain.size()==size){       
      if(total==length){          
        return wordChain;
      }else{
        return bogus;
      }
    }   
    
    for(int each: children){
      if(!(wordChain.contains(each))){
        ArrayList<Integer> chain = (ArrayList<Integer>) wordChain.clone();
        chain.add(each);
        bogus=findEnd(each,chain,length,size);
        if(!(bogus.isEmpty())){
          return bogus;
        }               
        //if((wordChain.contains(each))){
        //return bogus;
        // }
      }
    }
    return bogus;
  }
}



















