package Version_7;

public enum State{
    UNVISITED, VISITED_SELF,VISITED_DESCENDANTS;    
}