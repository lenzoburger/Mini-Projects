package etude5;
import java.util.*;

public class Piece{
    public String piece;
    public ArrayList matchRankings= new ArrayList();
    //private boolean isReverse=false;
    Map<String, Integer> relationships = new TreeMap<String, Integer>();
    public Piece(String strip){
        reverseIt(strip);
    }
    private void reverseIt(String strip){
        int num;
        makeCarpet stock = new makeCarpet();
        //stock.size=strip.length();
        String reverse= new StringBuilder(strip).reverse().toString();
        if(stock.Cstock.containsKey(reverse)){
            piece= reverse;
            stock.count++;
            stock.strips.add(reverse);
            num=stock.Cstock.get(reverse);
            stock.Cstock.remove(reverse);
            stock.Cstock.put(reverse,num+1);
        }else if(stock.Cstock.containsKey(strip)){
            piece= strip;
            stock.count++;
            stock.strips.add(strip);
            num=stock.Cstock.get(strip);
            stock.Cstock.remove(strip);
            stock.Cstock.put(strip,num+1);
        }else{
            //System.out.println(reverse+ " <> "+k);
            stock.Cstock.put(strip,1);
            //stock.uniqueStrips++;
            piece= strip;
            stock.count++;
            stock.strips.add(strip);
            stock.uniqueStrips.add(strip);
        }
    }

    
    private int matches(String p1, String p2){
        int matching=0;
        int revMatch=0;
        String reverse= new StringBuilder(p2).reverse().toString();
        for(int i=0;i<p2.length();i++){
            if(p1.charAt(i)==p2.charAt(i)){
                matching++;
            }
            if(p1.charAt(i)==reverse.charAt(i)){
                revMatch++;
            }
        }
        if(revMatch>matching){
            //isReverse=true;
            return revMatch;
        }
        return matching;
    }
    
    public void matchCalculator(ArrayList uniqueStrips,Map<String, Integer> oldStock){
        HashMap<String, Integer> stock = new HashMap<String, Integer>();
        stock.putAll(oldStock);
        String temp;
        makeCarpet mC = new makeCarpet();
        //Object store;
        for(Object each: uniqueStrips){
            temp=each.toString();
            relationships.put(temp,matches(piece,temp));
        }
        //store= piece;
        //System.out.println(piece +": " + stock.get(piece));
        System.out.println(piece +": " + relationships.get(piece));
        relationships=mC.sortValues(relationships);
        System.out.println(piece +": " + relationships.get(piece));
        if(stock.get(piece)<2){
            relationships.remove(piece);
        }
        Set Cset= relationships.entrySet();
        Iterator Citerator= Cset.iterator();
        while(Citerator.hasNext()) {
            Map.Entry mEntry = (Map.Entry)Citerator.next();
            for(i=0;)
            matchRankings.add(mEntry.getKey());
        }
        System.out.println("Match Rankings: " + matchRankings.toString());
        System.out.println(piece +": " + relationships.toString());
        
    }
    
    /*public String checkReverse(String k){
        k= new StringBuilder(k).reverse().toString();
        if(reversed.containsKey(k)){
            return k;
        }
        return k= new StringBuilder(k).reverse().toString();
    }*/
    
    /*public int getVal(HashMap<String, Integer> stockT, String k){
        if(reversed.containsKey(k)){
            //System.out.println("reverse me: " + k);
            k= new StringBuilder(k).reverse().toString();
            return stockT.get(k);
        }
        return stockT.get(k);
    }*/
    
    
    
    
}




