package Version_9;

public enum State{
    UNVISITED, VISITED_SELF,VISITED_DESCENDANTS;    
}