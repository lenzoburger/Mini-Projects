// File: carpet.java - March 2015 
package Etude5;

/**
 * A class which uses an instance of the class java.util.HashMap to hold
 * capet strips and number of stock and produces a carpet matching aesthestics criteria specifed.
 *
 * @author Daisy, Lencho, Lennox, Nikhil.
 */

import java.util.HashMap;

public class carpet {

    /** Create an instance of HashMap */
    private HashMap<String, Integer>Cstock = new HashMap<String,Integer>();

    public void noMatches() {
        System.out.println("no Matches");
    }

    public void maxMatches() {
        System.out.println("max Matches");
    }

    public void balMatches() {
        System.out.println("bal Matches");
    }
    
    /** Return the number in stock to which the specified carpet strip is mapped
     *  @param name: the specified carpet strip
     *  @return the corresponding number of stock available
     */
    public Integer inStock(String key) {
        return Cstock.get(key);
    }
   
    /** Return true if this map contains a mapping for the carpet strip
     *  @param key: the specified carpet strip
     *  @return true or false
     */
    public boolean contains(String key) {
        return Cstock.containsKey(key);
    }
   
    /** Return a string representation of this map
     *  @return a string of the map
     */
    public String toString() {
        return Cstock.toString();
    }
   
    /** Add an entry with the given name and number to the map
     *  @param k: the specified carpet strip
     *         v: the number of stock
     */
    public void addEntry(String k, int v) {
        Cstock.put(k, v);
    }
   
    /** Return the number of capet strip and  in_stock mappings in this map
     *  @return size of the map
     */
    public int size() {
        return Cstock.size();
    }
   
    /** Remove the mapping for the specified carpet strip from this map
     *  @param n: the specified carpet strip
     */
    public void remove(String n) {
        Cstock.remove(n);
    }

}
