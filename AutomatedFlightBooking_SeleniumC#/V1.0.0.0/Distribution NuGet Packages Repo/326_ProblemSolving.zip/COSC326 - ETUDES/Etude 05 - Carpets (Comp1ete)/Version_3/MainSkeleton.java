package etude5;
import java.util.*;

public class makeCarpet {
    public static Map<String, Integer>Cstock = new TreeMap<String, Integer>();
    
    public static void main(String[] args) {
        
        ArrayList<Piece> pieces = new ArrayList<>();
        int n = Integer.parseInt(args[0]);
        Scanner in = new Scanner(System.in);
        while (in.hasNextLine()) {
            pieces.add(new Piece(in.nextLine()));    
        }
        switch (args[1]) {
        	case "-n":
        		makeNoMatchCarpet(n, pieces);
        		break;
        	case "-m":
        		makeMaxMatchCarpet(n, pieces);
        		break;
        	case "-b":
        		makeBalancedCarpet(n, pieces);
        		break;
        	default:
        		throw new IllegalArgumentException("Bad argument");
        }
        
    }
    
    public static void makeNoMatchCarpet(int n, ArrayList<Piece> pieces){
        System.out.println("makeNoMatchCarpet");
    }
    
    public static void makeMaxMatchCarpet(int n, ArrayList<Piece> pieces){
        Cstock=sortValues(Cstock);
        System.out.println("Max Matches: " );
        
    }
    
    public static void makeBalancedCarpet(int n, ArrayList<Piece> pieces){
        System.out.println("makeBalancedMatchCarpet");
    }
    
    public static <K, V extends Comparable<V>> Map<K, V> sortValues(final Map<K, V> map) {
        Comparator<K> compareValues =  new Comparator<K>() {
            public int compare(K k1, K k2) {
                int compare = map.get(k2).compareTo(map.get(k1));
                if (compare == 0) return 1;
                else return compare;
            }
        };
        Map<K, V> sortValues = new TreeMap<K, V>(compareValues);
        sortValues.putAll(map);
        return sortValues;
    }
}