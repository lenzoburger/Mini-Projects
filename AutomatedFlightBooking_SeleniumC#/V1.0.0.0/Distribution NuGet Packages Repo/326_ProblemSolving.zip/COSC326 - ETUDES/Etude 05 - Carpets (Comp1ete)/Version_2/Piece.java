package etude5;
import java.util.*;

public class Piece{
    private String piece;
    private boolean isReverse=false;
    HashMap<String, Integer> reversed = new HashMap<String, Integer>();
    HashMap<String, Integer> buffer = new HashMap<String, Integer>();
    public Piece(){
    }
    
    public Piece(String strip){
        piece=strip;
        reverseIt(strip);
    }
    
    private void reverseIt(String strip){
        int num;
        makeCarpet stock = new makeCarpet();
        stock.size=strip.length();
        String reverse= new StringBuilder(strip).reverse().toString();
        if(stock.Cstock.containsKey(reverse)){
            num=stock.Cstock.get(reverse);
            stock.Cstock.remove(reverse);
            stock.Cstock.put(reverse,num+1);
        }else if(stock.Cstock.containsKey(strip)){
            num=stock.Cstock.get(strip);
            stock.Cstock.remove(strip);
            stock.Cstock.put(strip,num+1);
        }else{
            //System.out.println(reverse+ " <> "+k);
            stock.Cstock.put(strip,1);
            stock.uniqueStrips++;
        }
    }
    
    public int maxMatch(int n,int size, Map<String, Integer> stockT, ArrayList ol){
        HashMap<String, Integer> stock = new HashMap<String, Integer>();
        stock.putAll(stockT);
        int remainder=n;
        String previous="111";
        String p;
        String next="null";
        int matching=0;
        int sum;
        if(stock.get(ol.get(0))>=n){
            for(int i=0;i<n;i++){
                System.out.println(ol.get(0));
            }
            return size*(n-1);
            
        }else{
            p=ol.get(0).toString();
            p=checkReverse(p);
            matching+= (size*(getVal(stock,p)-1));
            buffer.put(p,getVal(stock,p));
            remainder-=getVal(stock,p);
            while(remainder>0){
                for(int i=1;i<ol.size();i++){
                   next=ol.get(i).toString();
                    sum=getVal(stock,p)+ getVal(stock,next);
                    if(sum>=remainder){
                        if(matches(p,next)==(size-1)){
                            System.out.println("p: " +p+" next: "+ next);
                            if(isReverse){
                                next= new StringBuilder(next).reverse().toString();
                                reversed.put(next,1);
                                isReverse=false;
                            }
                            //sum=matches(p,next);
                            //System.out.println("next: "+ p + " "  + next +" "  +sum);
                            //sum=matches(previous,p);
                            //System.out.println("previous: " + previous + " "  + p +" "  + sum);
                            previous=p;
                            p=next;
                            sum=matches(previous,p);
                            matching+=sum;
                            System.out.println("previous: " + previous + " "  + p +" "  + sum);
                            if(getVal(stock,p)>remainder){
                                matching+= (size*(remainder-1));
                                buffer.put(p,remainder);
                                remainder-=remainder;
                            }else{
                                matching+= (size*(getVal(stock,p)-1));
                                buffer.put(p,getVal(stock,p));
                                remainder-=getVal(stock,p);
                            }
                            break;
                        }
                    }else if(getVal(stock,p)==getVal(stock,next)){
                        
                    }
                }
            }
        }
        Set Cset= buffer.entrySet();
        Iterator Citerator= Cset.iterator();
        while(Citerator.hasNext()) {
            Map.Entry mEntry = (Map.Entry)Citerator.next();
            String val= mEntry.getValue().toString();
            int value= Integer.parseInt(val);
            for(int i=0;i<value;i++){
                System.out.println(mEntry.getKey());
            }
        }
        return matching;
    }
    
    private int matches(String p1, String p2){
        int matching=0;
        int revMatch=0;
        String reverse= new StringBuilder(p2).reverse().toString();
        for(int i=0;i<p2.length();i++){
            if(p1.charAt(i)==p2.charAt(i)){
                matching++;
            }
            if(p1.charAt(i)==reverse.charAt(i)){
                revMatch++;
            }
        }
        if(revMatch>matching){
            isReverse=true;
            return revMatch;
        }
        return matching;
    }
    
    public String checkReverse(String k){
        k= new StringBuilder(k).reverse().toString();
        if(reversed.containsKey(k)){
            return k;
        }
        return k= new StringBuilder(k).reverse().toString();
    }
    
    public int getVal(HashMap<String, Integer> stockT, String k){
        if(reversed.containsKey(k)){
            //System.out.println("reverse me: " + k);
            k= new StringBuilder(k).reverse().toString();
            return stockT.get(k);
        }
        return stockT.get(k);
    }
}




