// Etude 2 Lennox Huang 1663448
import java.util.Scanner;
import java.lang.System;

public class PokersApp {
  
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    String card = "";
    
    while (input.hasNextLine()) {
      card = input.nextLine();
      card = checkSeparator(card);
    }
  }
    
  // make sure the list only used one separator type
  public static String checkSeparator(String card) {
    char letter = ' ';
    int space = 0;
    int dash = 0;
    int slash = 0;
    for (int i = 0; i < card.length(); i++) {
      letter = card.charAt(i);
      if (letter == ' ') {
        space++;
      } else if (letter == '-') {
        dash++;
      } else if (letter == '/') {
        slash++;
      }
    }
    if (dash == 4 || space == 4 || slash == 4) {
      check(card);
    } else {
      System.out.println("Invalid: " + card);
      return "";
    }
    return card;
  }
 
  // check the format
  public static String check(String card) {
    String st = card.toUpperCase();
    String cards[] = st.split("[-\\s\\/]"); // Split
    String newLine = "";
    String lastLetter = card.substring(card.length() - 1);
    int count = 0;
    
    if (lastLetter.toUpperCase().matches("[C|D|H|S]")) {  // make sure no extra separator in the last position
      for (String c : cards) {
        Boolean b = c.matches("^([1-9]|1[0-3]|[ATJQK])[CDHS]$"); // check every card format
        
        if (b == true) {
          count++;
          newLine += c + " ";
        } else if (b == false){
          System.out.println("Invalid: " + card);
          return "";
        }
      }
    } else {
      System.out.println("Invalid: " + card);
      return "";
    }
    
    if (count != 5) {  // Can only have 5 pokers in one hand
      System.out.println("Invalid: " + card);
      return "";
    }
    
    card = replace(newLine, card);
    return card;
  }
  
  // replace case and check duplicate
  public static String replace(String card, String originalCard) {
    String cards[] = card.split("\\s+");
    String result = "";
    
    for(String c : cards) {
      String tmp = c;     
      
      if (c.length() == 2 && c.substring(0,1).equals("1")) {
        c = "A" + tmp.substring(1,2);    
        if (result.contains(c)) {
          System.out.println("Invalid: " + originalCard);
          return "";
        }    
        result += c + " ";
      } else if (c.length() == 2){     
        if (result.contains(c)) {
          System.out.println("Invalid: " + originalCard);
          return "";
        }     
        result += c + " ";
      }
      
      if (c.length() == 3) {
        if (c.substring(0, 2).equals("10")) {
          if (result.contains(c)) {
            System.out.println("Invalid: " + originalCard);
            return "";
          }
          result += c + " ";
        } else if (c.substring(0, 2).equals("11")) {
          c = "J" + tmp.substring(2, 3);
          if (result.contains(c)) {
            System.out.println("Invalid: " + originalCard);
            return "";
          }
          result += c + " ";
        } else if (c.substring(0, 2).equals("12")) {
          c = "Q" + tmp.substring(2, 3);
          if (result.contains(c)) {
            System.out.println("Invalid: " + originalCard);
            return "";
          }
          result += c + " ";
        } else if (c.substring(0, 2).equals("13")) {
          c = "K" + tmp.substring(2, 3);
          if (result.contains(c)) {
            System.out.println("Invalid: " + originalCard);
            return "";
          }
          result += c + " ";
        }
      } 
    }    
    System.out.println(result);
    return result;
  }
  
} // End of the class