import java.util.*;
public class Threes{
  public static int count=0;
  public static int count2=0;
  
  public static void main(String [] args){
    System.out.println("CALCULATING values ordered by x");
    int x=3;
    int z=2;
    while(count<=70){
      increasingX(x);
      x++;
    }
    System.out.println("CALCULATING values ordered by z");
    while(count2<=70){
      increasingZ(z);
      z++;
    }
    
  }
  
  
  public static void increasingX(int x){
    long  ySqr = 1;
    long  xSqr = x*x;
    long  z = 1;
    long  lB = ((z*z*z*z) + 1) / 2;   
    
    while (z < x) {
      lB = ((z*z*z*z) + 1) / 2;
      ySqr = (((z*z*z*z) + 1) - xSqr);
      if ((xSqr < ySqr) && pSqr(ySqr)) {      
        ySqr = (long)Math.sqrt(ySqr);
          if(noFactors(xSqr,ySqr,(int)z)){
        System.out.println("x =   " +  x +"  y =   " + ySqr +  "  z =   " + z);
        count++;
          }
      }
      z++;
    }
  }
  
  public static void increasingZ(int z){  
    long  ySqr = 1;
    long  xSqr = 3;
    long  uB = (z*z*z*z)+1;  
    //System.out.println(uB);
    while (xSqr<uB) {
      //System.out.println(uB);
      ySqr = (long)(((z*z*z*z) + 1) - Math.pow(xSqr,2));
      if(ySqr>0){
        if ((xSqr < ySqr) && pSqr(ySqr)) {
          ySqr = (long)Math.sqrt(ySqr);
          if(noFactors(xSqr,ySqr,z)){
            System.out.println("x =   " +  xSqr +"  y =   " + ySqr +  "  z =   " + z);
            count2++;
            return;
          }
        }
      }
      xSqr++;
    }
    return;
  }
  
  public static boolean pSqr(long ySqr){
    long square = (long)Math.sqrt(ySqr);
    if (square * square == ySqr) {
      return true;
    } else {
      return false;
    }
  }
  
  
  
  public static boolean noFactors(long x, long y, int z){
//    if(gCD(x,y)==1||gCD(x,z)==1){
//      return false;
//    }
//    if(gCD(y,z)==1){
//      return false;
//    }
//    return true;
    return gCD(x,y)==1 && gCD(x,z)==1 && gCD(y,z)==1;
  }
  
  
  private static long gCD(long a, long b) {    
      while(a!=0 && b!=0){ // until either one of them is 0
      
        long c = b;
        b = a%b;
        a = c;
      }
      return a+b; // either one is 0, so return the non-zero value
    }
    
}