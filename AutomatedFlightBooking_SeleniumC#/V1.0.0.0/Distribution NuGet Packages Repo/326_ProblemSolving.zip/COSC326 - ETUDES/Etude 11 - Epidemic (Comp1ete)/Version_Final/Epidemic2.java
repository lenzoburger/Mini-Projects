// Lennox Huang 1663448
import java.util.*;

public class Epidemic2 {
  public static char[][] theList;
  public static char[][] theListCopy;
  public static boolean update = false, otherUpdate = false;
  // public static boolean getOri = false;
  public static int count = 0;
  
  public static void main(String[] args) {   
    String firstString;
    ArrayList<String> list = new ArrayList<String>();
    Scanner input = new Scanner(System.in);
    firstString = input.nextLine();
    
    if (firstString.matches("[.IS]*")) {
      list.add(firstString);
      while (input.hasNextLine()) { 
        String nextString;
        nextString = input.nextLine();
        
        if (nextString.equals("")) {  // Run 
          if (!list.isEmpty()) {
            checkNeighbour(list);
            changeAllSick(theList); // Make all Sick first 
            //checkChange(theList);
            finalCheck(theList);
            printOut(theList);
            list.clear();
            // getOri = false;
          }
        } else if (nextString.matches("[.IS]*")) {  //add
          list.add(nextString);
        } else {
          System.out.println("NO MATCHES OR NOT SAME LENGTH");
          break;
        }        
      }
    }
    
    if (!list.isEmpty()) {
      checkNeighbour(list);
      changeAllSick(theList); // Make all Sick first 
      do {  
        update = false;     
        //checkChange(theList);
        finalCheck(theList);
      } while (update);          
      printOut(theList);
      System.out.println();
      list.clear();
    }
  }    
  
  public static void changeAllSick(char[][] sickArray) {
    
    int len = sickArray[0].length;
    /*
    for (int i = 0; i < sickArray.length; i++) {   
      for (int j = 0; j < len; j++) {
        if (sickArray[i][j] != 'S' && getOri == false) {
          System.out.println("original");
          
          printOut(theList);
          System.out.println();
          getOri = true;
        }
      }
    }
    */
    for (int i = 0; i < sickArray.length; i++) {   
      for (int j = 0; j < len; j++) {
        if (sickArray[i][j] == '.') {
          sickArray[i][j] = 'S';
        }
      }
    }
  }
  
  public static void checkChange(char[][] sickArray) {
    
    int len= sickArray[0].length;
    
    for (int i = 0; i < sickArray.length; i++) {   
      for (int j = 0; j < len; j++) {
        if (sickArray[i][j] == 'S') {
          int check = 0;
          if (i > 0) {
            if (sickArray[i - 1][j] == 'S') { // TOP
              check++;
            }
          }
          
          if (i < (sickArray.length - 1)) {
            if (sickArray[i + 1][j] == 'S') { // BOT
              check++;
            }
          }
          
          if (j > 0) {
            if (sickArray[i][j - 1] == 'S') { // LEF
              check++;
            }
          }
          
          if (j < len - 1) {
            if (sickArray[i][j + 1] == 'S' ) {  // RIG
              check++;
            }
          }
          
          if (check >= 2) { // Replace
            sickArray[i][j] = '.';
            // System.out.println("checking if correct");
            // copy the array first
            char[][] copiedArray = Arrays.copyOfRange(sickArray, 0, sickArray.length);
            
            for (int me = 0; me < sickArray.length; me++) {
              copiedArray[me] = Arrays.copyOfRange(sickArray[me], 0, sickArray[me].length);
            }
            
            do {
              otherUpdate = false;
              copiedArray = checkSickness(copiedArray);                
            } while (otherUpdate);
            // if not all healthy, then make myself sick again.
            if (!countHealthy(copiedArray)) {
              sickArray[i][j] = 'S';
            } else {
              count++;
            }
          }          
        }
      }
    }   
    // System.out.println("madesick: " + countSick(sickArray));
  } 
  
  public static void finalCheck(char[][] sickArray) {
    //checkChange(sickArray);
    int len= sickArray[0].length;
    
    for (int i = 0; i < sickArray.length; i++) {   
      for (int j = 0; j < len; j++) {
        if (sickArray[i][j] == 'S') {
          sickArray[i][j] = '.';
          checkChange(sickArray);
                      char[][] copiedArray = Arrays.copyOfRange(sickArray, 0, sickArray.length);
            
            for (int me = 0; me < sickArray.length; me++) {
              copiedArray[me] = Arrays.copyOfRange(sickArray[me], 0, sickArray[me].length);
            }
            
            do {
              otherUpdate = false;
              copiedArray = checkSickness(copiedArray);                
            } while (otherUpdate);
            // if not all healthy, then make myself sick again.
            if (!countHealthy(copiedArray)) {
              sickArray[i][j] = 'S';
            } else {
              count++;
            }
        }
      }
    }   
    System.out.println("madesick: " + countSick(sickArray));
  }
  
   public static int countSick(char[][] population) {
    int sick = 0;
    
    for (char[] row : population) {
      for (char col : row) {
        if (col == 'S') {
          sick++;
        }
      }
    }
    return sick; // if no healthy, this is true
  }
  
  public static boolean countHealthy(char[][] population) {
    int healthy = 0;
    
    for (char[] row : population) {
      for (char col : row) {
        if (col == '.') healthy++;
      }
    }
    return healthy == 0; // if no healthy, this is true
  }
  
  public static char[][] checkSickness(char[][] sickArray) {
    int len= sickArray[0].length;
    
    for (int i = 0; i < sickArray.length; i++) {   
      for (int j = 0; j < len; j++) {

        if (sickArray[i][j] == '.') {
          int sick = 0;
          if (i > 0) {
            if (sickArray[i - 1][j] == 'S') { // TOP
              sick++;
            }
          }
          
          if (i < (sickArray.length - 1)) {
            if (sickArray[i + 1][j] == 'S') { // BOT
              sick++;
            }
          }
          
          if (j > 0) {
            if (sickArray[i][j - 1] == 'S') { // LEF
              sick++;
            }
          }
          
          if (j < len - 1) {
            if (sickArray[i][j + 1] == 'S' ) {  // RIG
              sick++;
            }
          }
          
          if (sick >= 2) { // Replace 
            sickArray[i][j] = 'S';
            otherUpdate = true;
          }
        }
      }
    }
    return sickArray;
  }
  
  public static String checkNeighbour(ArrayList<String> list) {
    int len;
    len = list.get(0).length();
    theList = new char[list.size()][len];
    
    for (int i = 0; i < list.size(); i++) {   
      for (int j = 0; j < len; j++) {
        theList[i][j]=list.get(i).charAt(j);
      }
    }    
    return "";
  }
  
  public static void printOut(char[][] charArray) {
    for(char[] each: charArray){
      for(char individual: each){
        System.out.print(individual + "");
      }  
      System.out.println();
    }
    System.out.println();
  }
  
}

