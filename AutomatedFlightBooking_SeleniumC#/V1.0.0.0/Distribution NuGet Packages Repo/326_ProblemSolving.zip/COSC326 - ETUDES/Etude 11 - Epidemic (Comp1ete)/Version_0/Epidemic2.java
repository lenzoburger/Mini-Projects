// Lennox Huang 1663448
import java.util.*;

public class Epidemic2 {
    public static char[][] theList;
    public static boolean update = false;
    
    public static void main(String[] args) {   
        String firstString;
        ArrayList<String> list = new ArrayList<String>();
        Scanner input = new Scanner(System.in);
        firstString = input.nextLine();
    
        if (firstString.matches("[.IS]*")) {
            list.add(firstString);
      
            while (input.hasNextLine()) { 
                String nextString;
                nextString = input.nextLine();
        
                if (nextString.equals("")) {  
                    if (!list.isEmpty()) {
                        checkNeighbour(list);
                        do {  
                            update = false;
                            checkSickness(theList);
                        } while (update);
                        
                      /*  
                      if(theList.length > 1){
                         pruneSurplus(theList);
                        checkSickness(theList);
                       }
                       */
                        printOut(theList);
                        System.out.println();
                        list.clear();
                    }
                } else if (nextString.matches("[.IS]*")) {
                    list.add(nextString);
                } else {
                    System.out.println("NO MATCHES OR NOT SAME LENGTH");
                    break;
                }        
            }
        }
    
        if (!list.isEmpty()) {
            checkNeighbour(list);
            do {  
                update = false;
                checkSickness(theList);
            } while (update);
            /*
           if(theList.length > 1){
              pruneSurplus(theList);
           }
            */           
            
            printOut(theList);
            System.out.println();
            list.clear();
        }
    }
    
    public static void checkSickness(char[][] sickArray) {
        int len = sickArray[0].length;
        int madeSick = 0;
        for (int i = 0; i < sickArray.length; i++) {   
            for (int j = 0; j < len; j++) {
                if (sickArray[i][j] == '.') {
                    int notSick = 0;
                    int sizeA = sickArray.length;
                    
                    if (i > 0) {
                        if (sickArray[i - 1][j] == '.') { // TOP
                            notSick++;
                        }
                    }

                    // Check Single Line
                    if (i < (sickArray.length)) {
                        if (i + 1 == sizeA && i - 1 == -1) {
                            if (j == 0) {
                                sickArray[i][0] = 'S';
                                madeSick++;
                                update = true;
                            }
                            if (j == len - 1) {
                                sickArray[i][len-1] = 'S';
                                madeSick++;
                                update = true;
                            }
                            
                            if (j > 0) {
                                if (sickArray[i][j - 1] == 'I') { 
                                    sickArray[i][j] = 'S';
                                    madeSick++;
                                    update = true;
                                }
                            }
          
                            if (j < len - 1) {
                                if (sickArray[i][j + 1] == 'I') { 
                                    sickArray[i][j] =  'S';
                                    madeSick++;
                                    update = true;
                                }
                            }
                        }                        
                    }
          
                    if (i < (sickArray.length - 1)) {
                        if (sickArray[i + 1][j] == '.') { // BOT
                            notSick++;
                        }
                    }
          
                    if (j > 0) {
                        if (sickArray[i][j - 1] == '.') { // LEF
                            notSick++;
                        }
                    } 
                    if (j < len - 1) {
                        if (sickArray[i][j + 1] == '.') {  // RIG
                            notSick++;
                        }
                    } 
                    
                    if (notSick >= 2) { // Replace 
                        sickArray[i][j] = 'S';
                        update = true;
                        madeSick++;
                    }
                }
            }
        }
        if (update == true) {
            System.out.println("madeSick: " + madeSick);
        }
    }
    
    /*
    public static void pruneSurplus(char[][] sickArray) {
        int len = sickArray[0].length;
        int madeSick = 0;
        for (int i = 0; i < sickArray.length; i++) {   
            for (int j = 0; j < len; j++) {
                if (sickArray[i][j] == 'S') {
                    int sick = 0;
                    int sizeA = sickArray.length;
                    
                    if (i > 0) {
                        if (sickArray[i - 1][j] == 'S') { // TOP
                            sick++;
                        }
                    }

                    if (i < (sickArray.length - 1)) {
                        if (sickArray[i + 1][j] == 'S') { // BOT
                            sick++;
                        }
                    }
          
                    if (j > 0) {
                        if (sickArray[i][j - 1] == 'S') { // LEF
                            sick++;
                        }
                    }
          
                    if (j < len - 1) {
                        if (sickArray[i][j + 1] == 'S') {  // RIG
                            sick++;
                        }
                    }
                    if (sick >= 2) { // Replace 
                        sickArray[i][j] = '.';
                    }
                }
            }
        }
    }
  */
    
    public static String checkNeighbour(ArrayList<String> list) {
        int len;
        len = list.get(0).length();
        theList = new char[list.size()][len];
        
        for (int i = 0; i < list.size(); i++) {   
            for (int j = 0; j < len; j++) {
                theList[i][j]=list.get(i).charAt(j);
            }
        }    
        return "";
    }
  
    public static void printOut(char[][] charArray) {
        for(char[] each: charArray){
            for(char individual: each){
                System.out.print(individual+"");
            }  
            System.out.println();
        }
    }

}

