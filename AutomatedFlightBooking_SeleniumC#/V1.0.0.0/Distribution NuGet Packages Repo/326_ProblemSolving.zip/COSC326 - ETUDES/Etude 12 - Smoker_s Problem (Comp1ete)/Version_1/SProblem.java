package Version_1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by lburka on 5/8/15.
 */
public class SProblem {
    private static int rows;
    private static int cols;
    public static Grid g;

    public static void main(String [] args){
        ArrayList<int[]> nonSmokers= new ArrayList<int[]>();
        Scanner input= new Scanner(System.in);
        Scanner s= new Scanner(input.nextLine());
        rows = s.nextInt();
        cols = s.nextInt();
        //System.out.println(rows + " " + cols);
        //String store=input.nextLine();
        //System.out.println("rows: " + rows +" cols: "+cols);
        while(input.hasNextLine()) {
            String line=input.nextLine();
            if(line.equals("")){
                g= new Grid(rows,cols,nonSmokers);
                //g.printGrid(g.vertexList);
                g.Dijkstra(nonSmokers, 0); // DFS checking
                g.printGrid(g.vertexList);
                //System.out.println(g.vertexList[7][3].nearest);//The neighbours
                g=null;
                nonSmokers.clear();
                Scanner l= new Scanner(input.nextLine());
                rows = l.nextInt();
                cols = l.nextInt();
                //System.out.println(rows + " " + cols);
            }else{
                int[] coord= new int[2];
                Scanner l= new Scanner(line);
                coord[0]=l.nextInt();
                coord[1]=l.nextInt();
                nonSmokers.add(coord);
                //System.out.println(coord[0] + " " + coord[1]);
                //String line = input.nextLine();
            }
        }
        g= new Grid(rows,cols,nonSmokers);
        g.Dijkstra(nonSmokers, 0); // DFS checking
        g.printGrid(g.vertexList);

    }
}
