package Version_0;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by lburka on 5/8/15.
 */
public class SProblem {
    private static int rows;
    private static int cols;
    public static Grid g;

    public static void main(String [] args){
        ArrayList<int[]> nonSmokers= new ArrayList<int[]>();
        Scanner input= new Scanner(System.in);
        rows = input.nextInt();
        cols = input.nextInt();
        //String store=input.nextLine();
        //System.out.println("rows: " + rows +" cols: "+cols);
        while(input.hasNextInt()) {
            int[] coord= new int[2];
            coord[0]=input.nextInt();
            coord[1]=input.nextInt();
            nonSmokers.add(coord);
            //System.out.println("x: " + coord[0] + "y: " + coord[1]);
            //String line = input.nextLine();
        }
        g= new Grid(rows,cols,nonSmokers);
        //g.printGrid(g.vertexList);
        g.Dijkstra(nonSmokers, 0); // DFS checking
        //System.out.println(g.vertexList[7][3].nearest);//The neighbours
    }
}
