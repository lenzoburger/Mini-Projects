package Version_2;

import java.util.ArrayList;

public class Smoker {
    public boolean start=false;
    public boolean end= false;
    public String label;
    public boolean smoker;
    public int x;        // label (e.g. 'A')
    public int y;
    ArrayList<Smoker> neighbours= new ArrayList<Smoker>();
    public Smoker left;
    public Smoker right;
    public Smoker up;
    public Smoker down;
    public Smoker nearest;
    public int nearestDist;
    public int dist;

    public Smoker(int x, int y, boolean smoker, int maxRows, int maxCols) {
        this.x=x;
        this.y=y;
        this.smoker=smoker;
        this.label=y + "," + x;
        if(x==0&&y==0) {
            start = true;
        }else if(maxRows-1==y && maxCols-1 ==x){
            end=true;
        }
        dist=y+x;
    }

    public String toString() {
        return label;
    }
}
