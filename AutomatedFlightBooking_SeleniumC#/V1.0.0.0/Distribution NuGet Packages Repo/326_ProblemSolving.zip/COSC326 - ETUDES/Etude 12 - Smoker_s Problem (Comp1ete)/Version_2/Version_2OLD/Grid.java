package Version_2;

import java.util.ArrayList;

/**
 * Created by lburka on 5/8/15.
 */
public class Grid {
    static  Smoker[][] vertexList;
    public Grid(int rows, int cols, ArrayList<int[]> coord) {
        vertexList= new Smoker[rows][cols];
        for(int r=0;r<rows;r++){
            for(int c=0;c<cols;c++){
                vertexList[r][c]= new Smoker(c,r,true,rows,cols);
            }
        }

        for(int[] each: coord){
            vertexList[each[1]][each[0]].smoker=false;
        }

        for(int row=0;row<rows;row++) {
            for(int col=0;col<cols;col++) {
                Smoker curr= vertexList[row][col];
                Smoker left;
                Smoker right;
                Smoker up;
                Smoker down;
                if(row==0){
                    up=null;
                }else{
                    up=vertexList[row-1][col];
                }
                if(row==rows-1){
                    down=null;
                }else{
                    down= vertexList[row+1][col];
                }
                if(col==0){
                    left=null;
                }else{
                    left= vertexList[row][col-1];
                }
                if(col==cols-1){
                    right=null;
                }else{
                    right=vertexList[row][col+1];
                }
                curr.left=left;
                curr.right=right;
                curr.up=up;
                curr.down=down;
                if(left!=null) {
                    //curr.neighbours.add(left);

                }
                curr.down=down;
                if(right!=null) {
                    curr.neighbours.add(right);
                }
                if(up!=null) {
                    //curr.neighbours.add(up);
                }
                if(down!=null) {
                    curr.neighbours.add(down);
                }
                //System.out.println(curr + ":  LEFT -> " + curr.left + "  RIGHT -> " + curr.right + " UP -> " + curr.up + " DOWN -> " + curr.down);
                findNearest(curr,coord);
            }
        }
    }

    public void printGrid(Smoker[][] grid){
        int p=0;
        while(p<grid[0].length) {
        System.out.print(p + "  ");
            p++;
        }
        System.out.println();
        for(int i=0; i<grid.length;i++){
            for(int j=0;j<grid[i].length;j++){
                if(grid[i][j].end) {
                    System.out.print("E  ");
                }else if(grid[i][j].start){
                    System.out.print("S  ");
                }else if(grid[i][j].smoker){
                    System.out.print("0  ");
                }else{
                    System.out.print("1  ");
                }
            }
            System.out.println(i);
        }
    }

    public void findNearest(Smoker me, ArrayList<int[]> nonSmokers) {
        int myX=me.x;
        int myY=me.y;
        Smoker best = me;
        int minDistance = Integer.MAX_VALUE;
        for(int[] each: nonSmokers) {
            int x=vertexList[each[1]][each[0]].x;
            int y=vertexList[each[1]][each[0]].y;
            int distY= Math.max(myY-y,y-myY);
            int distX= Math.max(myX-x,x-myX);
            int dist= distY+distX;
            if (dist<minDistance) {
                minDistance=dist;
                best=vertexList[each[1]][each[0]];
            }
        }
        me.nearest=best;
        me.nearestDist=minDistance;
    }

    public static void dfs(Smoker start, int min, int dist, int finalY, int finalX) {
        ArrayList<Smoker> neighbours;
        neighbours= start.neighbours;
        Smoker best=neighbours.get(0);
        int bestDist= Integer.MAX_VALUE;
        int bestmin=0;
        for(Smoker each: neighbours){

            int myDist=(finalY-each.y)+(finalX-each.x);
            if(each.end){
                System.out.println("min: "+ min + " Total: " + dist);
                return;
            }
            if(each.nearestDist>=bestmin){
                best=each;
                bestDist= myDist;
                bestmin=each.nearestDist;
            }
            if(each.nearestDist==bestmin && myDist < bestDist){
                best=each;
                bestDist= myDist;
                bestmin=each.nearestDist;
            }
        }
        if(bestmin<min){
            min=bestmin;
        }
        dfs(best,min,dist+1,finalY,finalX);
    }
}
