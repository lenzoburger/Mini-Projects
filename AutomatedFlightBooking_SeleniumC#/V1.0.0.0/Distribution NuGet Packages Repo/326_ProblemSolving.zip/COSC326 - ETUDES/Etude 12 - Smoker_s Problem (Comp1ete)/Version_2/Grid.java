package Version_2;

import java.util.ArrayList;

/**
 * Created by lburka on 5/8/15.
 */
public class Grid {
    public int minimum=0;
    public int tot=0;
    ArrayList<int[]> nonS;
    static  Smoker[][] vertexList;
    public Grid(int rows, int cols, ArrayList<int[]> coord) {
        vertexList= new Smoker[rows][cols];
        for(int r=0;r<rows;r++){
            for(int c=0;c<cols;c++){
                vertexList[r][c]= new Smoker(c,r,true,rows,cols);
            }
        }

        for(int[] each: coord){
            vertexList[each[1]][each[0]].smoker=false;
            vertexList[each[1]][each[0]].label="1  ";
        }

        for(int row=0;row<rows;row++) {
            for(int col=0;col<cols;col++) {
                Smoker curr= vertexList[row][col];
                Smoker left;
                Smoker right;
                Smoker up;
                Smoker down;
                if(row==0){
                    up=null;
                }else{
                    up=vertexList[row-1][col];
                }
                if(row==rows-1){
                    down=null;
                }else{
                    down= vertexList[row+1][col];
                }
                if(col==0){
                    left=null;
                }else{
                    left= vertexList[row][col-1];
                }
                if(col==cols-1){
                    right=null;
                }else{
                    right=vertexList[row][col+1];
                }
                curr.left=left;
                curr.right=right;
                curr.up=up;
                curr.down=down;
                if(left!=null) {
                    //curr.neighbours.add(left);

                }
                curr.down=down;
                if(right!=null) {
                    curr.neighbours.add(right);
                }
                if(up!=null) {
                    //curr.neighbours.add(up);
                }
                if(down!=null) {
                    curr.neighbours.add(down);
                }
                //System.out.println(curr + ":  LEFT -> " + curr.left + "  RIGHT -> " + curr.right + " UP -> " + curr.up + " DOWN -> " + curr.down);
                findNearest(curr,coord);
            }
        }
    }

    public void printGrid(Smoker[][] grid){
        int p=0;
        while(p<grid[0].length) {
        //System.out.print(p + "  ");
            p++;
        }
        System.out.println();
        for(int i=0; i<grid.length;i++){
            for(int j=0;j<grid[i].length;j++){
                if(grid[i][j].end) {
                    System.out.print("E  ");
                }else if(grid[i][j].start){
                    System.out.print("S  ");
                }else{
                    System.out.print(grid[i][j]);
                }
            }
            System.out.println();
        }
    }

    public void findNearest(Smoker me, ArrayList<int[]> nonSmokers) {
        nonS=nonSmokers;
        int myX=me.x;
        int myY=me.y;
        Smoker best = me;
        int minDistance = Integer.MAX_VALUE;
        for(int[] each: nonSmokers) {
            int x=vertexList[each[1]][each[0]].x;
            int y=vertexList[each[1]][each[0]].y;
            int distY= Math.max(myY-y,y-myY);
            int distX= Math.max(myX-x,x-myX);
            int dist= distY+distX;
            if (dist<minDistance) {
                minDistance=dist;
                best=vertexList[each[1]][each[0]];
            }
        }
        me.nearest=best;
        me.nearestDist=minDistance;
    }

    public ArrayList<Integer> totDist(ArrayList<Integer> dist, Smoker me){
        int myX=me.x;
        int myY=me.y;
        if(dist.size()==0){
            //System.out.println("empty right now");
            for (int[] each: nonS){
                int x=vertexList[each[1]][each[0]].x;
                int y=vertexList[each[1]][each[0]].y;
                int distY= Math.max(myY-y,y-myY);
                int distX= Math.max(myX-x,x-myX);
                int distance= distY+distX;
                dist.add(distance);
            }
        }else{
            for (int i=0;i<nonS.size();i++) {
                int x = vertexList[nonS.get(i)[1]][nonS.get(i)[0]].x;
                int y = vertexList[nonS.get(i)[1]][nonS.get(i)[0]].y;
                int distY = Math.max(myY - y, y - myY);
                int distX = Math.max(myX - x, x - myX);
                int distance = distY + distX;
                if (distance < dist.get(i)) {
                    dist.set(i,distance);
                    //System.out.println("changing stuff");
                }
            }
        }
            return dist;
    }

    public int myTotal(ArrayList<Integer> org, Smoker me){
        ArrayList<Integer> dist= (ArrayList<Integer>)org.clone();
        int myX=me.x;
        int myY=me.y;
        for (int i=0;i<nonS.size();i++) {
            int x = vertexList[nonS.get(i)[1]][nonS.get(i)[0]].x;
            int y = vertexList[nonS.get(i)[1]][nonS.get(i)[0]].y;
            int distY = Math.max(myY - y, y - myY);
            int distX = Math.max(myX - x, x - myX);
            int distance = distY + distX;
            if (distance < dist.get(i)) {
                dist.set(i, distance);
                //System.out.println("changing stuff");
            }
        }
        int total=0;
        for(int d: dist){
            total+=d;
        }
        return total;
    }

    public int myTD(Smoker me){
        int myX=me.x;
        int myY=me.y;
        int totalDist=0;
        for (int[] each: nonS){
            //System.out.println("empty rght now");
            int x=vertexList[each[1]][each[0]].x;
            int y=vertexList[each[1]][each[0]].y;
            int distY= Math.max(myY-y,y-myY);
            int distX= Math.max(myX-x,x-myX);
            int distance= distY+distX;
            totalDist+=distance;
        }
        return totalDist;
    }

    public void dfs(Smoker start, int min,ArrayList<Integer> totalDist) {
        ArrayList<Smoker> neighbours;
        totalDist= totDist(totalDist, start);
        neighbours= start.neighbours;
        Smoker best=neighbours.get(0);
        int bestmin=neighbours.get(0).nearestDist;
        int neighBestMin=0;
        for(Smoker each: neighbours){
            //System.out.println(myTotal(totalDist, each));
            ArrayList<Smoker> n= each.neighbours;
            int bestN=0;
            if(each.end){
                totalDist= totDist(totalDist, each);
                System.out.print("min " + min);
                minimum=min;
                return;
            }
            for(Smoker ne: n){
                if(ne.nearestDist>bestN){
                    bestN=ne.nearestDist;
                }
            }
            if(each.nearestDist>bestmin){
                best=each;
                bestmin=each.nearestDist;
                neighBestMin=bestN;

            }else if(each.nearestDist==bestmin && bestN>neighBestMin){
                best=each;
                bestmin=each.nearestDist;
                neighBestMin=bestN;
            }
        }

        if(bestmin<min){
            min=bestmin;
        }
        best.label="*  ";
        dfs(best,min,totalDist);
    }

    public void findTotal(int min, Smoker me,ArrayList<Integer> totalDist){
        ArrayList<Integer> totList=totDist(totalDist,me);
        int myTotal=myTotal(totList,me);
        ArrayList<Smoker> neighbours;
        neighbours= me.neighbours;
        int bestTotal=0;
        for(Smoker you: neighbours){
            ArrayList<Integer> newTList=(ArrayList<Integer>)totList.clone();
            if(you.end){
                int to=0;
                totList=totDist(totalDist,you);
                for(int each: totList) {
                    to += each;
                }
                //System.out.println(to);
                if(to>tot){
                    tot=to;
                    ////System.out.println(tot);
                }
            }
            if(you.nearestDist>=min){
                findTotal(min,you,newTList);
            }
        }
    }

}
