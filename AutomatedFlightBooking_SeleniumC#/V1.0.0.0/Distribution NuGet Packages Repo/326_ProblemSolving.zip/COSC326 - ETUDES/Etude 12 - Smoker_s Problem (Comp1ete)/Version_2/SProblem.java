package Version_2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by lburka on 5/8/15.
 */
public class SProblem {
    private static int rows;
    private static int cols;
    public static Grid g;

    public static void main(String [] args){
        ArrayList<int[]> nonSmokers= new ArrayList<int[]>();
        Scanner input= new Scanner(System.in);
        Scanner s= new Scanner(input.nextLine());
        rows = s.nextInt();
        cols = s.nextInt();
        while(input.hasNextLine()) {
            String line=input.nextLine();
            if(line.equals("")){
                g= new Grid(rows,cols,nonSmokers);
                ArrayList<Integer> dist= new ArrayList<Integer>();
                g.dfs(g.vertexList[0][0],g.vertexList[0][0].nearestDist,dist); // DFS checking
                ArrayList<Integer> td= new ArrayList<Integer>();
                g.findTotal(g.minimum,g.vertexList[0][0],td);
                System.out.println(", total " + g.tot);
                g=null;
                nonSmokers.clear();
                Scanner l= new Scanner(input.nextLine());
                rows = l.nextInt();
                cols = l.nextInt();
            }else{
                int[] coord= new int[2];
                Scanner l= new Scanner(line);
                coord[0]=l.nextInt();
                coord[1]=l.nextInt();
                nonSmokers.add(coord);
            }
        }
        g= new Grid(rows,cols,nonSmokers);
        ArrayList<Integer> dist= new ArrayList<Integer>();
        g.dfs(g.vertexList[0][0],g.vertexList[0][0].nearestDist,dist); // DFS checking
        ArrayList<Integer> td= new ArrayList<Integer>();
        g.findTotal(g.minimum,g.vertexList[0][0],td);
        System.out.println(", total " + g.tot);
        //g.printGrid(g.vertexList);
    }
}
