import java.util.*;

public class CountItUp {
  
  static double n;
  static double k;
  
  public static void main(String[] args) {
    
    n = Integer.parseInt(args[0]);
    k = Integer.parseInt(args[1]);
    calculate(n, k);
  }
  
  public static double factorial(double num) {
    if (num < 2) {
      return 1;
    }
    return num * factorial(num - 1);
  }
  
  public static double calculate(double n, double k){
    double result = 0;
    double bot = 0;
    
    if (n > k && n <= 52) {
      bot = factorial(k) * factorial(n - k);
      result = factorial(n)/bot;
      System.out.println("n = " + n + ", k = " + k +" This result is " + result);
    } else if (n == k) {
      result = 1;
      System.out.println(result);
      
    } else if (n > 52) {
        System.err.println("Poker only contains 52 cards.");
      } 
      return result;
    }
  }