//Etude 6 Lennox Huang 1663448
import javax.swing.*;
import java.awt.*;

public class Toothpicks extends JFrame{
  
  private static final long serialVersionUID = 1L;
  static int toothNums;
  static double ratio = 1;
  static double length = 250;
  static int x = 800/2;
  static int y = 800/2;
  
  public static void main(String[] args){
    Toothpicks frame = new Toothpicks();
    frame.setVisible(true);
    frame.setSize(800,800);
    toothNums = Integer.parseInt(args[0]);
    ratio = Double.parseDouble(args[1]);
    
    if (ratio > 1) {
      length = 400/(Math.pow(ratio, toothNums));
    }
    
    if (ratio == 1 && toothNums > 4) {
      length = length/2;
    } 
  }
  
  public void paint (Graphics g) {      
    setTitle("Toothpicks"); 
    g.drawLine(400 - (int)(length/2), 400, 400 + (int)(length/2), 400);    
    drawToothpicks(g, x, y, toothNums, length);    
  }
  
  public void drawToothpicks(Graphics g, int x, int y, int nums, double length){
    
    if (nums == 0) {       
      return;    
    }
   
    if(toothNums % 2 != 0) { // odd
      if (nums % 2 == 0) {
        evenTooth(g, x, y - (int)(length/2), length * ratio);  
        evenTooth(g, x, y + (int)(length/2), length * ratio);  
        drawToothpicks(g, x, y + (int)(length/2), nums - 1, length * ratio);
        drawToothpicks(g, x, y - (int)(length/2), nums - 1, length * ratio); 
      } else {
        oddTooth(g, x - (int)(length/2), y, length * ratio);  
        oddTooth(g, x + (int)(length/2), y, length * ratio);
        drawToothpicks(g, x - (int)(length/2), y, nums - 1, length * ratio);
        drawToothpicks(g, x + (int)(length/2), y, nums - 1, length * ratio);     
      }
    } else {  //even
      if (nums % 2 != 0) {
        evenTooth(g, x, y - (int)(length/2), length * ratio);  
        evenTooth(g, x, y + (int)(length/2), length * ratio);  
        drawToothpicks(g, x, y + (int)(length/2), nums - 1, length * ratio);
        drawToothpicks(g, x, y - (int)(length/2), nums - 1, length * ratio); 
      } else {
        oddTooth(g, x - (int)(length/2), y, length * ratio);  
        oddTooth(g, x + (int)(length/2), y, length * ratio);
        drawToothpicks(g, x - (int)(length/2), y, nums - 1, length * ratio);
        drawToothpicks(g, x + (int)(length/2), y, nums - 1, length * ratio);     
      }
    }
  }
  
  public void evenTooth(Graphics g, int x, int y, double length) {
    g.drawLine(x - (int)(length/2), y, x +(int)(length/2), y);
  }
  
  public void oddTooth(Graphics g, int x, int y, double length) { 
    g.drawLine(x ,y - (int)(length/2), x, y + (int)(length/2));
  }
  
}
